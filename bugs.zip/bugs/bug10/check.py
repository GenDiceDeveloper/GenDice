import numpy as np
import onnx

from tvm import relay
from tvm.relay import testing
import tvm
from tvm import te
from tvm.contrib import graph_runtime

onnx_model = onnx.load('bug.onnx')
mod, params = relay.frontend.from_onnx(onnx_model, {})

# print(mod.astext(show_meta_data=False))

opt_level = 3
target = "llvm"

with relay.build_config(opt_level=opt_level):
	tvm_graph, tvm_lib, tvm_params = relay.build_module.build(mod, target, params=params)

ctx = tvm.cpu(0)
module = graph_runtime.create(tvm_graph, tvm_lib, ctx)
module.load_params(relay.save_param_dict(tvm_params))
module.run()
out_deploy = module.get_output(0).asnumpy()
print(out_deploy)
