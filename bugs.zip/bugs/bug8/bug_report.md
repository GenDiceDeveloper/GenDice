[Bug] Wrong result with model contains Flatten and Reduce

## Description

When compiling following model with TVM, it will output different result with onnxruntime. By manually checking, I found the result of TVM may be wrong.

The model(with ONNX as frontend) with error is as follows, check bug.onnx in bug8.zip.



Here is the relay program.

```
#[version = "0.0.5"]

def @main(%node1: Tensor[(3, 3, 2, 3, 2, 5), float32]) {

 %0 = reshape(%node1, newshape=[-1]);

 %1 = abs(%0);

 sum(%1, axis=[0], keepdims=True)

}
```

I think the shape of correct result should be (1, 540) instead of (1).



## How to reproduce

### Environment

Python3, with tvm, onnx, onnxruntime

tvm version(latest): https://github.com/apache/tvm/commit/1f2b40fe371d22aaadc27fc1cc77778b59201f0f

1. Download 
2. Run `python check.py`.