Our experiments are based on Python 3.

Install TVM:

```
https://tvm.apache.org/docs/install/index.html
```

Install ONNX and ONNX-Runtime: 
```
pip install onnx==1.8.0
pip install onnxruntime
```


In our experiment, we use ONNX as 1.8.0 and TVM0.7 (the first bug are on TVM unstable version: [`c31e338`](https://github.com/apache/tvm/commit/c31e338d5f98a8e8c97286c5b93b20caee8be602)).

How to reproduce bugs:

For example, `cd bug/bug-1; python check.py` to reproduce each bug.

