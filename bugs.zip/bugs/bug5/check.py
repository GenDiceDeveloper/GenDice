import numpy as np
import onnx

from tvm import relay
from tvm.relay import testing
import tvm
from tvm import te
from tvm.contrib import graph_runtime

onnx_model = onnx.load('bug.onnx')
mod, params = relay.frontend.from_onnx(onnx_model, {})

