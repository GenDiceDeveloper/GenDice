[Bug] Error when compiling a ONNX model with Gemm operator


## Description

When compiling following model with TVM, it will crash.

The model(with ONNX as frontend) with error is as follows, check bug.onnx in bug6.zip.


## Error Log

```
tensor type `Tensor[(5), float32]` has 1 dimensions, while `Tensor[(4, 5), float32]` has 2 dimensions
The Relay type checker is unable to show the following types match.
In particular `Tensor[(5), float32]` does not match `Tensor[(4, 5), float32]`

tvm.error.DiagnosticError: Traceback (most recent call last):
  [bt] (8) 9   libtvm.dylib                        0x000000011a18ab7c tvm::transform::PassNode::operator()(tvm::IRModule) const + 60
  [bt] (7) 8   libtvm.dylib                        0x000000011a286415 tvm::transform::SequentialNode::operator()(tvm::IRModule, tvm::transform::PassContext const&) const + 869
  [bt] (6) 7   libtvm.dylib                        0x000000011a286792 tvm::transform::Pass::operator()(tvm::IRModule, tvm::transform::PassContext const&) const + 194
  [bt] (5) 6   libtvm.dylib                        0x000000011a2862fc tvm::transform::SequentialNode::operator()(tvm::IRModule, tvm::transform::PassContext const&) const + 588
  [bt] (4) 5   libtvm.dylib                        0x000000011a286792 tvm::transform::Pass::operator()(tvm::IRModule, tvm::transform::PassContext const&) const + 194
  [bt] (3) 4   libtvm.dylib                        0x000000011a284f25 tvm::transform::ModulePassNode::operator()(tvm::IRModule, tvm::transform::PassContext const&) const + 789
  [bt] (2) 3   libtvm.dylib                        0x000000011acc53f9 std::__1::__function::__func<void tvm::runtime::TypedPackedFunc<tvm::IRModule (tvm::IRModule, tvm::transform::PassContext)>::AssignTypedLambda<tvm::relay::transform::InferType()::$_1>(tvm::relay::transform::InferType()::$_1)::'lambda'(tvm::runtime::TVMArgs const&, tvm::runtime::TVMRetValue*), std::__1::allocator<void tvm::runtime::TypedPackedFunc<tvm::IRModule (tvm::IRModule, tvm::transform::PassContext)>::AssignTypedLambda<tvm::relay::transform::InferType()::$_1>(tvm::relay::transform::InferType()::$_1)::'lambda'(tvm::runtime::TVMArgs const&, tvm::runtime::TVMRetValue*)>, void (tvm::runtime::TVMArgs, tvm::runtime::TVMRetValue*)>::operator()(tvm::runtime::TVMArgs&&, tvm::runtime::TVMRetValue*&&) + 2025
  [bt] (1) 2   libtvm.dylib                        0x000000011a2440cc tvm::DiagnosticContext::Render() + 476
  [bt] (0) 1   libtvm.dylib                        0x000000011a017c6f dmlc::LogMessageFatal::~LogMessageFatal() + 111
  File "/Documents/tvm/src/ir/diagnostic.cc", line 105
DiagnosticError: one or more error diagnostics were emitted, please check diagnostic render for output.
```

## How to reproduce

### Environment

Python3, with tvm, onnx

tvm version: [`c31e338`](https://github.com/apache/tvm/commit/c31e338d5f98a8e8c97286c5b93b20caee8be602) Wed Dec 9 14:52:58 2020 +0900

1. Download 
2. Run `python check.py`.